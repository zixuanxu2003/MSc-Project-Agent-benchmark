import json

# 读取当前的多行格式文件
with open('level1.jsonl', 'r') as f:
    content = f.read()

# 按 "}\n{" 分割成多个 JSON 字符串
# 先把每个对象合并成一行
import re

# 找到每个完整的 JSON 对象（从 { 到 }）
objects = []
current = ""
brace_count = 0
for char in content:
    if char == '{':
        brace_count += 1
    elif char == '}':
        brace_count -= 1
    current += char
    if brace_count == 0 and current.strip():
        objects.append(current.strip())
        current = ""

# 重新写入，每行一个 JSON 对象
with open('level1_fixed.jsonl', 'w') as f:
    for obj_str in objects:
        # 解析并重新转成紧凑格式（一行）
        obj = json.loads(obj_str)
        f.write(json.dumps(obj) + '\n')