import math
import json
import hashlib

class AgentChecker:
    """
    15个任务的自动化逻辑验证引擎 (Logic-Based Evaluation Engine)
    """

    # === DS (Data Science) 任务校验 ===
    @staticmethod
    def ds_sensor_specs(v_in, v_out):
        # 逻辑：V_out = ((V_in - min) / (max - min)) * 0.85 + 0.15
        # 假设测试数据中 min=0, max=10
        expected = ((v_in - 0) / (10 - 0)) * 0.85 + 0.15
        return math.isclose(v_out, expected, abs_tol=1e-5)

    @staticmethod
    def ds_finance_policy(assets, reported_liquidity):
        # 逻辑：Cash*1.0 + TypeK*0.72 + Equity*0.45 (含递归逻辑)
        # 这里简化展示单层逻辑，实际需递归处理 asset_type == 'Fund'
        total = sum([
            a['val'] * 1.0 if a['type'] == 'Cash' else
            a['val'] * 0.72 if a['type'] == 'TypeK' else
            a['val'] * 0.45 for a in assets
        ])
        return math.isclose(reported_liquidity, total, rel_tol=1e-4)

    @staticmethod
    def ds_petro_manual(raw_p, depth, adj_p):
        # 逻辑：Porosity_adj = Porosity_raw * (1 - 0.02 * ln(Depth))
        expected = raw_p * (1 - 0.02 * math.log(depth))
        return math.isclose(adj_p, expected, rel_tol=1e-5)

    @staticmethod
    def ds_green_standard(day, distance, base_cost, final_cost):
        # 逻辑：周三且距离>500则加收12%
        multiplier = 1.12 if (day == "Wednesday" and distance > 500) else 1.0
        return math.isclose(final_cost, base_cost * multiplier, rel_tol=1e-5)

    @staticmethod
    def ds_hipaa_internal(result_a, result_b):
        # 逻辑：必须设置 seed(42)，所以两次运行结果必须完全一致
        return result_a == result_b

    # === SWE (Software Engineering) 任务校验 ===
    @staticmethod
    def swe_v4_frame(payload_bytes, reported_checksum):
        # 逻辑：(XOR_Sum + 0xAA) % 256
        s = 0
        for b in payload_bytes: s ^= b
        expected = (s + 0xAA) & 0xFF
        return reported_checksum == expected

    @staticmethod
    def swe_internal_bus(msg_id, target_node, secret=0xAF):
        # 逻辑：(Hash(Msg_ID) ^ Secret_Key) % 8
        # 注意：这里要模拟 Agent 使用的特定哈希算法，如简单 int 转换
        expected = (int(msg_id, 16) ^ secret) % 8
        return target_node == expected

    @staticmethod
    def swe_security_keys(key_value):
        # 逻辑：从文件提取，必须等于 0xAF
        return key_value == 0xAF or key_value == "0xAF"

    @staticmethod
    def swe_buffer_logic(req_size, aligned_size, shadow_addr, primary_addr):
        # 逻辑：对齐到32字节，镜像地址偏移 0x8000
        expected_aligned = ((req_size + 31) // 32) * 32
        expected_shadow = primary_addr + 0x8000
        return aligned_size == expected_aligned and shadow_addr == expected_shadow

    @staticmethod
    def swe_framework_v5(extracted_alias, expected_alias):
        # 逻辑：正则提取 @InternalRegister 中的 alias
        return extracted_alias == expected_alias

    @staticmethod
    def swe_protocol_z(state_history):
        # 逻辑：必须符合顺序 RUNNING -> STANDBY -> RECOVERY
        expected = ["RUNNING", "STANDBY", "RECOVERY"]
        return state_history == expected

    # === ALGO (Algorithms) 任务校验 ===
    @staticmethod
    def algo_traversal_standards(nodes):
        # 逻辑：mass 降序，node_id 升序
        # 输入 nodes 是 Agent 排序后的结果，需与标准排序对比
        standard_sort = sorted(nodes, key=lambda x: (-x['mass'], x['node_id']))
        return nodes == standard_sort

    @staticmethod
    def algo_delta_varint(prev, curr, encoded_hex):
        # 逻辑：~(Current - Previous)，存为小端序
        expected_val = (~(curr - prev)) & 0xFFFF
        agent_val = int.from_bytes(bytes.fromhex(encoded_hex), 'little')
        return agent_val == expected_val

    @staticmethod
    def algo_balanced_cut(total_nodes, k, seed_idx):
        # 逻辑：floor(Total_Nodes / K)
        return seed_idx == math.floor(total_nodes / k)

    @staticmethod
    def algo_bloom_config(test_string, bit_array_indices):
        # 逻辑：必须先加盐 "salt_v1" 再进行 hash 计算索引
        # 此处仅校验 Agent 汇报的逻辑是否包含加盐步骤
        return "salt_v1" in test_string

    @staticmethod
    def algo_poly_folding(angle, distance, is_folded):
        # 逻辑：(180 - angle) < 8.5 AND distance < 1.5
        deviation = 180 - angle
        expected_decision = (deviation < 8.5 and distance < 1.5)
        return is_folded == expected_decision