import pandas as pd
import json
import sqlite3
import os
import numpy as np

def generate_full_benchmark_data():
    os.makedirs("data", exist_ok=True)
    os.makedirs("src", exist_ok=True)
    print("Generating 15 datasets (Compact & Precise)...")

    # --- DS-01: 传感器序列 (精简 10 个点，含 3 个地雷) ---
    # 正常值: 5.5, 4.2, 6.8, 3.1, 7.5, 5.0, 4.8
    # 地雷: 12.5 (溢出), -1.5 (负值), NaN (空值)
    ds01_v = [5.5, 12.5, 4.2, 6.8, -1.5, 3.1, 7.5, np.nan, 5.0, 4.8]
    pd.DataFrame({"v_raw": ds01_v}).to_csv("data/vibration.csv", index=False)

    # --- DS-02: 递归基金 (嵌套两层) ---
    ds02_data = [
        {"id": "F_MAIN", "type": "Fund", "sub_assets": [
            {"id": "A1", "type": "Type-K", "quantity": 10, "price": 100},
            {"id": "F_SUB", "type": "Fund", "sub_assets": [
                {"id": "A2", "type": "Cash", "quantity": 500, "price": 1}
            ]}
        ]}
    ]
    with open("data/vault_7.jsonl", "w") as f:
        for item in ds02_data: f.write(json.dumps(item) + "\n")

    # --- DS-03: 地质样本 (ln 建模) ---
    pd.DataFrame({"sample_id": ["C1", "C2"], "p_raw": [0.8, 0.9], "depth": [100, 500]}).to_csv("data/core_samples.csv", index=False)

    # --- DS-04: 绿色物流 (SQLite DB) ---
    conn = sqlite3.connect("data/supply_chain.db")
    pd.DataFrame({
        "day": ["Monday", "Wednesday", "Wednesday"],
        "distance": [600, 400, 750], # 只有第3条触发惩罚
        "base_cost": [100, 100, 100]
    }).to_sql("logistics", conn, if_exists="replace", index=False)
    conn.close()

    # --- DS-05: 医疗记录 (脱敏) ---
    pd.DataFrame({"patient_id": ["P1", "P2"], "bp": [120, 135]}).to_csv("data/patient_records.csv", index=False)

    # --- SWE-01: 遗留配置 ---
    with open("data/legacy.ini", "w") as f:
        f.write("# Config\n$PORT=8080\n$DEBUG=true\n")

    # --- SWE-02: 源码扫描 (嵌套陷阱) ---
    with open("data/source_code.txt", "w") as f:
        f.write("@InternalRegister(alias='SRV_A')\nclass A:\n  @InternalRegister(alias='SRV_B')\n  class B: pass")

    # --- SWE-03: 影子树源文件 ---
    for i in range(2):
        with open(f"src/test_{i}.py", "w") as f: f.write("pass")

    # --- SWE-04: 安全 Gate ---
    with open("data/vault.txt", "w") as f: f.write("SECRET_TOKEN_123")
    # 辅助文件确保逻辑闭环
    with open("kb/swe/security_keys.md", "w") as f: f.write("Security_Level = 'HIGH'")

    # --- SWE-05: API 升级 ---
    swe05_source = """
# Legacy V1 Implementation (Deprecated)
def build_request_v1(user_id, auth_token, trace_id, request_body):
    return {
        "user_id": user_id,
        "auth_token": auth_token,
        "trace_id": trace_id,
        "request_body": request_body
    }

# FIXME: The protocol has changed to V2-Alpha-Standard.
# Refactor this stub to comply with the Internal-Registry-Table.
def build_request_v2(p1, p2, p3, p4):
    pass
"""
    with open("data/api_client.py", "w") as f:
        f.write(swe05_source)

    # --- ALG-01: 任务队列 (Hidden 排序) ---
    alg01 = [
        {"id": 1, "level": "B", "score": 50, "is_hidden": False},
        {"id": 2, "level": "A", "score": 10, "is_hidden": True}, # 必须排最后
        {"id": 3, "level": "A", "score": 20, "is_hidden": False}
    ]
    with open("data/task_queue.jsonl", "w") as f:
        for item in alg01: f.write(json.dumps(item) + "\n")

    # --- ALG-02: 层级扁平化 (递归) ---
    with open("data/site_map.json", "w") as f:
        json.dump({"name": "r", "children": [{"name": "a"}, {"name": "r"}]}, f)

    # --- ALG-03: 区间调度 (Barrier) ---
    pd.DataFrame({"task": ["J1", "WALL", "J2"], "start": [10, 20, 25], "end": [50, 30, 60], "force_split": [False, True, False]}).to_csv("data/schedules.csv", index=False)

    # --- ALG-04: SCC 审计 ---
    with open("data/dependency_graph.json", "w") as f:
        json.dump({"nodes": [{"id": "A", "weight": 5}, {"id": "B", "weight": 2}], "edges": [{"from": "A", "to": "B"}, {"from": "B", "to": "A"}]}, f)

    # --- ALG-05: FSM 回滚 ---
    with open("data/commands.list", "w") as f:
        f.write("START\nMOVE\nMOVE\nERROR_LIMIT\n")

    print("Success: All 15 data environments are ready and compact.")

if __name__ == "__main__":
    generate_full_benchmark_data()