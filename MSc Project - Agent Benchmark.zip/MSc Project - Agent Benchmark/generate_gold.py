import pandas as pd
import json
import os
import numpy as np

def generate_all_gold():
    os.makedirs("gold", exist_ok=True)
    print("Generating 15 Gold Standards (100% Field Alignment)...")

    # --- DS-01: Sensor (4 decimal places) ---
    v_raw = [5.5, 12.5, 4.2, 6.8, -1.5, 3.1, 7.5, np.nan, 5.0, 4.8]
    def ds01_calc(v):
        if np.isnan(v): return "0.1500"
        v = max(0.0, min(10.0, v))
        return "{:.4f}".format((v / 10.0) * 0.85 + 0.15)
    pd.DataFrame({"v_norm": [ds01_calc(x) for x in v_raw]}).to_csv("gold/ds_l1_001.csv", index=False)

    # --- DS-02: Finance (Recursive, 2 decimal places) ---
    # Calc: 10*100*0.72 (Type-K) + 500*1*1.0 (Cash) = 720 + 500 = 1220.00
    with open("gold/ds_l1_002.json", "w") as f:
        json.dump({"total_net_exposure": 1220.00}, f)

    # --- DS-03: Petro (ln, 4 decimal places) ---
    # C1: 0.8 * (1 - 0.02 * ln(100)) = 0.7263 | C2: 0.9 * (1 - 0.02 * ln(500)) = 0.7881
    pd.DataFrame({
        "sample_id": ["C1", "C2"],
        "p_adj": ["0.7263", "0.7881"]
    }).to_csv("gold/ds_l1_003.csv", index=False)

    # --- DS-04: Green Logistics (Integer) ---
    # Row 3 is Wed & 750km -> 100 * 1.12 = 112
    pd.DataFrame({
        "trip_id": [1, 2, 3],
        "final_cost": [100, 100, 112]
    }).to_csv("gold/ds_l1_004.csv", index=False)

    # --- DS-05: HIPAA (Fixed Seed 42) ---
    # 模拟固定种子下的确定性输出列名
    np.random.seed(42)
    bp_base = [120, 135]
    noise = np.random.laplace(0, 0.1, len(bp_base))
    bp_anon = [round(b + n, 4) for b, n in zip(bp_base, noise)]
    pd.DataFrame({
        "patient_id": ["P1", "P2"],
        "bp_anon": bp_anon
    }).to_csv("gold/ds_l1_005.csv", index=False)

    # --- SWE-01: Config (Lowercase + Inject) ---
    swe01 = {"port": "8080", "debug": "true", "_standardized": True}
    with open("gold/swe_l1_001.json", "w") as f:
        json.dump(swe01, f, sort_keys=True)

    # --- SWE-02: Registry (Upper Snake Case) ---
    swe02 = {"SRV_A": "A"}
    with open("gold/swe_l1_002.json", "w") as f:
        json.dump(swe02, f, sort_keys=True)

    # --- SWE-03: Shadow Tree (A-Z, .py.meta) ---
    with open("gold/swe_l1_003.txt", "w") as f:
        f.write("test_0.py.meta\ntest_1.py.meta")

    # --- SWE-04: Security Gate (Strict .env) ---
    with open("gold/swe_l1_004.env", "w") as f:
        f.write("VAULT_SECRET=ENC_SECRET_TOKEN_123")

    # --- SWE-05: API Upgrade ---
    swe05_gold = """def build_request_v2(p1, p2, p3, p4):
    return {"x_rec": p1, "a_auth": p2, "s_tid": p3, "p_load": p4}
    """
    with open("gold/swe_l1_005.py", "w") as f:
        f.write(swe05_gold)

    # --- ALG-01: Sort (Tier -> Score -> Hidden) ---
    # Result: ID 3 (A,20), ID 1 (B,50), ID 2 (A,10,Hidden)
    pd.DataFrame({"id": [3, 1, 2]}).to_csv("gold/alg_l1_001.csv", index=False)

    # --- ALG-02: Path ( [RECURSIVE]) ---
    alg02 = ["r/a", "r/r [RECURSIVE]"]
    with open("gold/alg_l1_002.json", "w") as f:
        json.dump(alg02, f)

    # --- ALG-03: Clipping (Non-merge, _1, _2 suffixes) ---
    gold_alg03 = [
        ["Job_1_1", 10, 20, False],
        ["WALL", 20, 30, True],
        ["Job_1_2", 30, 50, False],
        ["Job_2", 30, 60, False]
    ]
    pd.DataFrame(gold_alg03, columns=["task", "start", "end", "is_barrier"]).to_csv("gold/alg_l1_003.csv", index=False)

    # --- ALG-04: SCC (A-Z cycles, Desc Score) ---
    alg04 = [{"cycle_nodes": "A,B", "risk_score": 10.0}]
    with open("gold/alg_l1_004.json", "w") as f:
        json.dump(alg04, f)

    # --- ALG-05: FSM (Rollback 2) ---
    # Start -> Move(1) -> Move(2) -> ERROR -> Rollback 2 -> 0 Move left
    with open("gold/alg_l1_005.json", "w") as f:
        json.dump({"final_state": "STOP", "history_count": 0}, f)

    print("✅ All 15 Gold files generated in /gold.")

if __name__ == "__main__":
    generate_all_gold()