import json

def generate_tasks_jsonl():
    tasks = [
        # --- DATA SCIENCE (DS) ---
        {"task_id": "DS-01", "domain": "Data Science", "knowledge_base": "kb/ds/ds_01.md", "input_file": "data/vibration.csv", "output_dir": "output/", "initial_prompt": "Process 'data/vibration.csv' according to 'kb/ds/ds_01.md'."},
        {"task_id": "DS-02", "domain": "Data Science", "knowledge_base": "kb/ds/ds_02.md", "input_file": "data/vault_7.jsonl", "output_dir": "output/", "initial_prompt": "Execute valuation for 'data/vault_7.jsonl' based on 'kb/ds/ds_02.md'."},
        {"task_id": "DS-03", "domain": "Data Science", "knowledge_base": "kb/ds/ds_03.md", "input_file": "data/core_samples.csv", "output_dir": "output/", "initial_prompt": "Correct 'data/core_samples.csv' using the model in 'kb/ds/ds_03.md'."},
        {"task_id": "DS-04", "domain": "Data Science", "knowledge_base": "kb/ds/ds_04.md", "input_file": "data/supply_chain.db", "output_dir": "output/", "initial_prompt": "Audit 'data/supply_chain.db' as per 'kb/ds/ds_04.md'."},
        {"task_id": "DS-05", "domain": "Data Science", "knowledge_base": "kb/ds/ds_05.md", "input_file": "data/patient_records.csv", "output_dir": "output/", "initial_prompt": "Run HIPAA de-identification based on 'kb/ds/ds_05.md'."},

        # --- SOFTWARE ENGINEERING (SWE) ---
        {"task_id": "SWE-01", "domain": "Software Engineering", "knowledge_base": "kb/swe/swe_01.md", "input_file": "data/legacy.ini", "output_dir": "output/", "initial_prompt": "Transpile 'data/legacy.ini' using 'kb/swe/swe_01.md'."},
        {"task_id": "SWE-02", "domain": "Software Engineering", "knowledge_base": "kb/swe/swe_02.md", "input_file": "data/source_code.txt", "output_dir": "output/", "initial_prompt": "Scan 'data/source_code.txt' as specified in 'kb/swe/swe_02.md'."},
        {"task_id": "SWE-03", "domain": "Software Engineering", "knowledge_base": "kb/swe/swe_03.md", "input_file": "src/", "output_dir": "dist/shadow/", "initial_prompt": "Generate metadata for 'src/' following 'kb/swe/swe_03.md'."},
        {"task_id": "SWE-04", "domain": "Software Engineering", "knowledge_base": "kb/swe/swe_04.md", "input_file": "data/vault.txt", "output_dir": "output/", "initial_prompt": "Execute security injection based on 'kb/swe/swe_04.md'."},
        {"task_id": "SWE-05", "domain": "Software Engineering", "knowledge_base": "kb/swe/swe_05.md", "input_file": None, "output_dir": "project_root/", "initial_prompt": "Init project structure using 'kb/swe/swe_05.md'."},

        # --- ALGORITHM (ALG) ---
        {"task_id": "ALG-01", "domain": "Algorithm", "knowledge_base": "kb/algo/alg_01.md", "input_file": "data/task_queue.jsonl", "output_dir": "output/", "initial_prompt": "Sort 'data/task_queue.jsonl' per 'kb/algo/alg_01.md'."},
        {"task_id": "ALG-02", "domain": "Algorithm", "knowledge_base": "kb/algo/alg_02.md", "input_file": "data/site_map.json", "output_dir": "output/", "initial_prompt": "Resolve paths in 'data/site_map.json' per 'kb/algo/alg_02.md'."},
        {"task_id": "ALG-03", "domain": "Algorithm", "knowledge_base": "kb/algo/alg_03.md", "input_file": "data/schedules.csv", "output_dir": "output/", "initial_prompt": "Process intervals in 'data/schedules.csv' per 'kb/algo/alg_03.md'."},
        {"task_id": "ALG-04", "domain": "Algorithm", "knowledge_base": "kb/algo/alg_04.md", "input_file": "data/dependency_graph.json", "output_dir": "output/", "initial_prompt": "Audit cyclic risks in 'data/dependency_graph.json' per 'kb/algo/alg_04.md'."},
        {"task_id": "ALG-05", "domain": "Algorithm", "knowledge_base": "kb/algo/alg_05.md", "input_file": "data/commands.list", "output_dir": "output/", "initial_prompt": "Process commands in 'data/commands.list' per 'kb/algo/alg_05.md'."}
    ]

    with open('tasks.jsonl', 'w', encoding='utf-8') as f:
        for entry in tasks:
            # 关键点：使用 indent=4 展开 JSON，并手动加分隔符
            f.write(json.dumps(entry, indent=4))
            f.write("\n\n") # 每个 JSON 对象之间空两行，方便肉眼看
    print("Done: tasks.jsonl is now PRETTIFIED and EXPLICIT.")

if __name__ == "__main__":
    generate_tasks_jsonl()