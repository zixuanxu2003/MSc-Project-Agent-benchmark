import json

# Define the sorting priorities for levels
level_priority = {'A': 0, 'B': 1, 'C': 2}

# Load tasks from the file
def load_tasks(filepath):
    tasks = []
    with open(filepath, 'r') as f:
        for line in f:
            tasks.append(json.loads(line))
    return tasks

# Save tasks back to the file
def save_tasks(filepath, tasks):
    with open(filepath, 'w') as f:
        for task in tasks:
            f.write(json.dumps(task) + "\n")

# Sorting function
def reorder_tasks(tasks):
    # Rule: If is_hidden is True, force to bottom
    # Sort by:
    # 1) is_hidden (False first, True last)
    # 2) level (A > B > C) using level_priority
    # 3) score ascending
    
    return sorted(tasks, key=lambda x: (x['is_hidden'], level_priority.get(x['level'], 99), x['score']))


def main():
    filepath = 'data/task_queue.jsonl'
    tasks = load_tasks(filepath)
    reordered = reorder_tasks(tasks)
    save_tasks(filepath, reordered)

if __name__ == '__main__':
    main()