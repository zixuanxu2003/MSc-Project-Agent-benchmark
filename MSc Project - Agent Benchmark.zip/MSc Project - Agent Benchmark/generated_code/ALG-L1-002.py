import json

# Function to flatten the object hierarchy
# Uses a set to track visited nodes by their id to prevent circular references

def flatten_hierarchy(node, visited=None):
    if visited is None:
        visited = set()
    
    # Use id(node) for reference checking
    node_id = id(node)
    if node_id in visited:
        # Circular reference detected, skip to prevent infinite recursion
        return []
    
    visited.add(node_id)
    
    flattened = [node]
    children = node.get('children', [])
    if isinstance(children, list):
        for child in children:
            flattened.extend(flatten_hierarchy(child, visited))
    
    return flattened

# Load the JSON data
with open('data/site_map.json', 'r') as f:
    data = json.load(f)

# Flatten the hierarchy
flat_list = flatten_hierarchy(data)

# Save or print the results
# Here I will save the flattened list to a new JSON file
# since the flattened list might contain circular references, convert to a safe form that excludes children

def safe_node_repr(node):
    # Return node excluding children
    return {k: v for k, v in node.items() if k != 'children'}

flat_list_safe = [safe_node_repr(node) for node in flat_list]

with open('data/flat_site_map.json', 'w') as f:
    json.dump(flat_list_safe, f, indent=2)

print(f'Flattened hierarchy saved to data/flat_site_map.json - {len(flat_list_safe)} nodes.')
