import pandas as pd

# Read schedules.csv
schedules = pd.read_csv('data/schedules.csv')

# Create a new column for identifying barriers
schedules['is_barrier'] = schedules['force_split']

results = []

# Separate barriers and tasks
barriers = schedules[schedules['is_barrier']].copy()
tasks = schedules[~schedules['is_barrier']].copy()

# Sort barriers by start time
barriers = barriers.sort_values(by='start')

for _, task in tasks.iterrows():
    # For each task, check overlap with barriers
    overlapping_barriers = barriers[(barriers['start'] < task['end']) & (barriers['end'] > task['start'])]

    if overlapping_barriers.empty:
        # No barrier overlap, keep task as is
        results.append({
            'task': task['task'],
            'start': task['start'],
            'end': task['end'],
            'is_barrier': False
        })
    else:
        # There are overlapping barriers, split or clip the task around barriers
        segments = []
        current_start = task['start']

        for _, barrier in overlapping_barriers.iterrows():
            if current_start < barrier['start']:
                # Segment before barrier
                segments.append((current_start, barrier['start']))
            # Move start after barrier
            current_start = max(current_start, barrier['end'])

        # Final segment after last barrier if any
        if current_start < task['end']:
            segments.append((current_start, task['end']))

        # Add segments with proper naming
        for i, (seg_start, seg_end) in enumerate(segments):
            if len(segments) > 1:
                new_task_name = f"{task['task']}_{i+1}"
            else:
                new_task_name = task['task']
            results.append({
                'task': new_task_name,
                'start': seg_start,
                'end': seg_end,
                'is_barrier': False
            })

# Add barriers back to results
for _, barrier in barriers.iterrows():
    results.append({
        'task': barrier['task'],
        'start': barrier['start'],
        'end': barrier['end'],
        'is_barrier': True
    })

# Create output DataFrame
output_df = pd.DataFrame(results)

# Sort by start time
output_df = output_df.sort_values(by='start')

# Save to output file
output_df.to_csv('output/alg_l1_003.csv', index=False, columns=['task', 'start', 'end', 'is_barrier'])
