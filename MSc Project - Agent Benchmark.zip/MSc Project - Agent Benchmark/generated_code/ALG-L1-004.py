import json

# Load the graph data
with open('data/dependency_graph.json', 'r') as file:
    graph_data = json.load(file)

# Build adjacency list
adj_list = {node['id']: [] for node in graph_data['nodes']}
for edge in graph_data['edges']:
    adj_list[edge['from']].append(edge['to'])

# Find Strongly Connected Components (SCC) using Tarjan's Algorithm
index = 0
stack = []
on_stack = set()
indices = {}
lowlinks = {}
sccs = []


def strongconnect(node):
    global index
    indices[node] = index
    lowlinks[node] = index
    index += 1
    stack.append(node)
    on_stack.add(node)

    for neighbor in adj_list[node]:
        if neighbor not in indices:
            strongconnect(neighbor)
            lowlinks[node] = min(lowlinks[node], lowlinks[neighbor])
        elif neighbor in on_stack:
            lowlinks[node] = min(lowlinks[node], indices[neighbor])

    # If node is root of SCC
    if lowlinks[node] == indices[node]:
        scc = []
        while True:
            w = stack.pop()
            on_stack.remove(w)
            scc.append(w)
            if w == node:
                break
        sccs.append(scc)

for node in adj_list:
    if node not in indices:
        strongconnect(node)

# Map node weights
node_weights = {node['id']: node.get('weight', 1) for node in graph_data['nodes']}

# Compute risk score for each SCC: RiskScore = NodeCount * MaxWeightInSCC
risk_report = []
for scc in sccs:
    if len(scc) > 1:  # Only consider cyclic components (more than 1 node)
        max_weight = max(node_weights.get(n, 1) for n in scc)
        risk_score = len(scc) * max_weight
        risk_report.append({
            'cycle_nodes': ','.join(sorted(scc)),
            'risk_score': risk_score
        })

# Sort report by risk score descending
risk_report.sort(key=lambda x: x['risk_score'], reverse=True)

# Output the risk report
report_filename = 'output/cyclic_dependency_risk_report.json'
with open(report_filename, 'w') as outfile:
    json.dump(risk_report, outfile, indent=2)

print(f"Risk report generated and saved to {report_filename}")
