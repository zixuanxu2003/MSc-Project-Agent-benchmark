# Based on SPEC-ALG-305: FSM ROLLBACK
# Process the command stream and manage transactional rollbacks

# Read commands from file
with open('data/commands.list', 'r') as file:
    commands = file.read().strip().split('\n')

history = []
final_state = None

for cmd in commands:
    if cmd == 'MOVE':
        history.append(cmd)
    elif cmd == 'ERROR_LIMIT':
        # On ERROR_LIMIT, pop last 2 MOVE commands if possible
        for _ in range(2):
            if history and history[-1] == 'MOVE':
                history.pop()
        # Final state must transition to STOP
        final_state = 'STOP'
    elif cmd == 'START':
        # Initial state handling, we can ignore or mark
        pass

# Calculate history_count
history_count = len(history)
if history_count < 0:
    history_count = 0

# If final_state was not set by ERROR_LIMIT set it as per last command or
# default to some state, here assuming 'START' if no ERROR_LIMIT
if final_state is None:
    final_state = 'START'

# Output data
output = {
    'final_state': final_state,
    'history_count': history_count
}

# Save to the required output JSON file
import json
with open('output/alg_l1_005.json', 'w') as outfile:
    json.dump(output, outfile)

print(f"Processed commands. Final state: {final_state}, History count: {history_count}")
