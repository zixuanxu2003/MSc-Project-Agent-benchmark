import pandas as pd

# Load the raw vibration data
vibration_data = pd.read_csv('data/vibration.csv')

# Normalization specification from sensor_specs.md
# Logic:
# V_out = (V_in / 10.0) * 0.85 + 0.15
# Constraints:
# - Clamp V_in if > 10.0 to 10.0
# - Clamp V_in if < 0.0 to 0.0
# - If V_in is NaN, V_out must be 0.1500

def normalize_vibration(vin):
    if pd.isna(vin):
        return 0.1500
    # Clamp vin
    v_in_clamped = min(max(vin, 0.0), 10.0)
    # Normalize
    v_out = (v_in_clamped / 10.0) * 0.85 + 0.15
    return round(v_out, 4)  # 4 decimal places

# Apply normalization
vibration_data['v_norm'] = vibration_data['v_raw'].apply(normalize_vibration)

# Output to required file with exact 4 decimal places in float format
vibration_data[['v_norm']].to_csv('output/ds_l1_001.csv', index=False, float_format='%.4f')
