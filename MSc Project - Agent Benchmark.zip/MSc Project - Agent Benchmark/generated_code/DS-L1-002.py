import json

def calculate_net_exposure(fund):
    weights = {'Cash': 1.0, 'Type-K': 0.72}
    def helper(asset):
        if asset['type'] == 'Fund':
            # Recursively sum all sub_assets exposure
            return sum(helper(sub) for sub in asset.get('sub_assets', []))
        else:
            # Calculate weighted exposure
            weight = weights.get(asset['type'], 0.9)
            return asset['quantity'] * asset['price'] * weight
    return round(helper(fund), 2)

# Load the fund-of-funds data
with open('data/vault_7.jsonl', 'r') as f:
    fund_data = [json.loads(line) for line in f]

# We assume only one top-level fund in the file
fund = fund_data[0]

# Calculate the full net exposure
net_exposure = calculate_net_exposure(fund)

# Output results
result = {'total_net_exposure': net_exposure}

output_file = 'output/ds_l1_002.json'
with open(output_file, 'w') as f:
    json.dump(result, f)

print(f"Net Exposure calculated and saved to {output_file}: {net_exposure}")
