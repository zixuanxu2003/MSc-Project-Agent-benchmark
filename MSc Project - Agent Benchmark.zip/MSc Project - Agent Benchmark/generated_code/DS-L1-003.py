import pandas as pd
import math

# Load the data
file_path = 'data/core_samples.csv'
df = pd.read_csv(file_path)

# Apply the depth-compaction correction formula from SPEC-DS-103
# P_adj = P_raw * (1 - 0.02 * ln(depth))
# Using math.log for natural log

def apply_depth_compaction(row):
    return row['p_raw'] * (1 - 0.02 * math.log(row['depth']))

df['p_adj'] = df.apply(apply_depth_compaction, axis=1)

# Format the adjusted pressure to 4 decimal places

df['p_adj'] = df['p_adj'].round(4)

# Save the output file as per strict output protocol
output_path = 'output/ds_l1_003.csv'
df_out = df[['sample_id', 'p_adj']]
df_out.to_csv(output_path, index=False)