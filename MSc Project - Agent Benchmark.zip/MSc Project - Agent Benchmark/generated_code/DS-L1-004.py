import sqlite3
import pandas as pd

# Connect to the supply_chain.db SQLite database
conn = sqlite3.connect('data/supply_chain.db')
cursor = conn.cursor()

# Query the logistics table
query = 'SELECT rowid, day, distance, base_cost FROM logistics'
logistics_df = pd.read_sql_query(query, conn)

# Apply environmental penalty multiplier according to SPEC-DS-104
# Multiplier: 1.12x applies ONLY if (Day == "Wednesday" AND Distance > 500)

def calculate_final_cost(row):
    if row['day'] == 'Wednesday' and row['distance'] > 500:
        return round(row['base_cost'] * 1.12)
    else:
        return round(row['base_cost'])

logistics_df['final_cost'] = logistics_df.apply(calculate_final_cost, axis=1)

# Prepare output dataframe according to SPEC-DS-104
output_df = logistics_df[['rowid', 'final_cost']].rename(columns={'rowid': 'trip_id'})

# Save to output file
output_df.to_csv('output/ds_l1_004.csv', index=False)

conn.close()
