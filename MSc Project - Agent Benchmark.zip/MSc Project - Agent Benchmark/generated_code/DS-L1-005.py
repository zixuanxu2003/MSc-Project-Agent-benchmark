import pandas as pd
import numpy as np

# Set global random seed for deterministic noise
np.random.seed(42)

# Read the input file
input_file = 'data/patient_records.csv'
df = pd.read_csv(input_file)

# Apply Laplace noise for anonymization (scale=0.1 as per HIPAA spec)
scale = 0.1

def laplace_noise(x, scale):
    noise = np.random.laplace(loc=0.0, scale=scale)
    return x + noise

# Create new anonymized bp column with _anon suffix
# Apply noise for anonymization
# Ensure deterministic noise by calling with global seed set above

# Because we want deterministic noise per row, we can generate noise anew but keep consistent by fixing seed globally
anon_bp = df['bp'].apply(lambda x: laplace_noise(x, scale))

# Build output dataframe
output_df = df.copy()
output_df['bp_anon'] = anon_bp

# Drop original 'bp' column if we want only anonymized
output_df = output_df.drop(columns=['bp'])

# Output file path
output_file = 'output/ds_l1_005.csv'

# Save to CSV
output_df.to_csv(output_file, index=False)
