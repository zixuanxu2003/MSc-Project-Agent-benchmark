import json

def transpile_legacy_ini_to_json(ini_path, json_path):
    with open(ini_path, 'r') as f:
        lines = f.readlines()

    result = {"_standardized": True}

    for line in lines:
        line = line.strip()
        # Ignore comments and empty lines
        if not line or line.startswith('#') or line.startswith(';'):
            continue
        # Parse $KEY=VAL
        if line.startswith('$') and '=' in line:
            key_val = line[1:].split('=', 1)
            key = key_val[0].strip().lower()
            val = key_val[1].strip()
            # Convert string booleans to bool type
            if val.lower() == 'true':
                val = True
            elif val.lower() == 'false':
                val = False
            elif val.isdigit():  # Convert numeric strings to int
                val = int(val)
            result[key] = val

    with open(json_path, 'w') as f:
        json.dump(result, f, indent=2)

# Example usage:
# transpile_legacy_ini_to_json('data/legacy.ini', 'output/swe_l1_001.json')
