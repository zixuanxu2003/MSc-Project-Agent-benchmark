from collections import defaultdict
import re

class InternalRegister:
    registry = {}

    def __init__(self, alias):
        self.alias = alias

    def __call__(self, cls):
        # Register the class with the given alias
        InternalRegister.registry[self.alias] = cls.__name__
        return cls

# This is the recreated decorator from the source to track registrations

# Emulating the source code
@InternalRegister(alias='SRV_A')
class A:
    @InternalRegister(alias='SRV_B')
    class B: pass

# Now we have a registry mapping aliases to internal class names

service_registry = InternalRegister.registry

print(service_registry)  # This will print {'SRV_A': 'A', 'SRV_B': 'B'}

# Export the registry dictionary for use
