import os

source_dir = 'src'
shadow_dir = 'dist/shadow'

# Ensure shadow directory exists
os.makedirs(shadow_dir, exist_ok=True)

# Read source directory files
source_files = sorted([f for f in os.listdir(source_dir) if f.endswith('.py')])

# Create shadow metadata files
for filename in source_files:
    shadow_file = f'{filename}.meta'
    shadow_path = os.path.join(shadow_dir, shadow_file)
    # Create zero-byte file to ensure strict physical isolation
    with open(shadow_path, 'w') as f:
        pass

print(f'Metadata shadow-tree created with {len(source_files)} files in "{shadow_dir}".')
