# Implements security gate check for deployment environment and injects corresponding API tokens

def inject_security_token():
    # Read the raw token from data/vault.txt
    with open('data/vault.txt', 'r') as f:
        raw_token = f.read().strip()

    # Read the security level from kb/security_keys.md
    security_level = 'LOW'  # default
    with open('kb/security_keys.md', 'r') as f:
        for line in f:
            if line.startswith('Security_Level:'):
                security_level = line.split(':')[1].strip()
                break

    # Apply rules
    if security_level == 'HIGH':
        processed_token = 'ENC_' + raw_token
    else:
        processed_token = raw_token

    # Write to output/swe_l1_004.env
    with open('output/swe_l1_004.env', 'w') as f:
        f.write(f'VAULT_SECRET={processed_token}')

# Execute the function
inject_security_token()
