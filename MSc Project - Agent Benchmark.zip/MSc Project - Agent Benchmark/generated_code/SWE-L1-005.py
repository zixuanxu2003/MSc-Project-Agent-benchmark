def build_request_v2(x_rec, a_auth, s_tid, p_load):
    return {
        "x_rec": x_rec,
        "a_auth": a_auth,
        "s_tid": s_tid,
        "p_load": p_load
    }
