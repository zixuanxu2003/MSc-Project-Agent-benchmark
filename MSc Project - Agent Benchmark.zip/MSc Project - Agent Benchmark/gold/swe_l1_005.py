def build_request_v2(p1, p2, p3, p4):
    return {"x_rec": p1, "a_auth": p2, "s_tid": p3, "p_load": p4}
    