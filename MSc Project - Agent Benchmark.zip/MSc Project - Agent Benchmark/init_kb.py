import os

def generate_all_kbs():
    # 创建目录结构
    os.makedirs("kb", exist_ok=True)

    kbs = {
        # --- Data Science 领域 ---
        "kb/sensor_specs.md": """# SPEC-DS-101: SENSOR CALIBRATION
## Logic
- Formula: $V_{out} = (V_{in} / 10.0) \\times 0.85 + 0.15$
- Constraints: 
    - If $V_{in} > 10.0$, clamp to $10.0$.
    - If $V_{in} < 0.0$, clamp to $0.0$.
    - If $V_{in}$ is NaN, $V_{out}$ must be 0.1500.
## [STRICT OUTPUT PROTOCOL]
- File: `output/ds_l1_001.csv`
- Header: `v_norm`
- Format: Float, exactly **4 decimal places** (e.g., 0.5750).""",

        "kb/finance_policy.md": """# SPEC-DS-102: FUND PENETRATION
## Logic
- Recursively sum all `sub_assets`.
- Weights: `Cash: 1.0`, `Type-K: 0.72`, `Other: 0.9`.
- Formula: $Exposure = \\sum (Quantity \\times Price \\times Weight)$.
## [STRICT OUTPUT PROTOCOL]
- File: `output/ds_l1_002.json`
- Key: `total_net_exposure`
- Format: Round to **2 decimal places**.""",

        "kb/petro_manual.md": """# SPEC-DS-103: LOGARITHMIC DECAY
## Logic
- Model: $P_{adj} = P_{raw} \\times (1 - 0.02 \\times \\ln(Depth))$
- Function: Use Natural Log (`math.log`).
## [STRICT OUTPUT PROTOCOL]
- File: `output/ds_l1_003.csv`
- Headers: `sample_id`, `p_adj`
- Format: `p_adj` must be **4 decimal places**.""",

        "kb/green_standard.md": """# SPEC-DS-104: LOGISTICS AUDIT
## Logic
- Multiplier: 1.12x applies ONLY if (`Day == "Wednesday"` AND `Distance > 500`).
- Base: Apply to `base_cost`.
## [STRICT OUTPUT PROTOCOL]
- File: `output/ds_l1_004.csv`
- Headers: `trip_id`, `final_cost`
- Format: `final_cost` must be an **Integer** (round to nearest).""",

        "kb/hipaa_internal.md": """# SPEC-DS-105: HIPAA ANONYMIZATION
## Logic
- Algorithm: Laplace Noise ($scale=0.1$).
- Consistency: Global random seed MUST be set to **42**.
## [STRICT OUTPUT PROTOCOL]
- File: `output/ds_l1_005.csv`
- Headers: Same as input with `_anon` suffix (e.g., `bp_anon`).""",

        # --- Software Engineering 领域 ---
        "kb/config_spec.md": """# SPEC-SWE-201: CONFIG MIGRATION
## Logic
- Parse `.ini` files. Ignore lines starting with `;` or `#`.
- Mapping: `$KEY=VAL` becomes `key: val`.
## [STRICT OUTPUT PROTOCOL]
- File: `output/swe_l1_001.json`
- Key: Mandatory **lowercase**.
- Injection: Root object must include `{"_standardized": true}`.""",

        "kb/framework_v5.md": """# SPEC-SWE-202: SERVICE REGISTRY
## Logic
- Target: Only register classes with `@InternalRegister` decorator.
- Scope: Top-Level classes only. Ignore nested classes.
## [STRICT OUTPUT PROTOCOL]
- File: `output/swe_l1_002.json`
- Key: Decorator `alias` attribute, forced to **SCREAMING_SNAKE_CASE**.
- Value: Class Name (string).""",

        "kb/buffer_logic.md": """# SPEC-SWE-203: SHADOW TREE
## Logic
- Operation: For every `.py` file in `src/`, create a 0-byte file in `dist/shadow/`.
## [STRICT OUTPUT PROTOCOL]
- File: `output/swe_l1_003.txt`
- Naming: Original filename + `.py.meta`.
- Order: Alphabetical **A-Z** by filename.""",
        
        "kb/security_keys.md": """# SECURITY KEYS
Security_Level: HIGH
""",

        "kb/security_policy.md": """# SPEC-SWE-204: VAULT INJECTION
## Logic
- Read the raw token from `data/vault.txt`.
- Check the `Security_Level` in `kb/security_keys.md`.
- **Rules**:
    - If `Security_Level` is 'HIGH', prefix the token with `ENC_`.
    - If 'LOW', use the raw token.
## [STRICT OUTPUT PROTOCOL]
- File: `output/swe_l1_004.env`
- Content: `VAULT_SECRET=[PROCESSED_TOKEN]`""",

        "kb/api_spec_v2.md": """# SPEC-SWE-205: CORPORATE API STANDARDS (V2)

## Section A: Service Migration
- Any stub labeled `V2-Alpha-Standard` must be refactored to use the new security aliases.
- Developers must fetch the correct mapping from the **Internal-Registry-Table** (see Section B).
- The legacy function (v1) in the source code is for reference only; do NOT reuse its keys.

## Section B: Internal-Registry-Table (Schema: AR-206)
| Legacy Field  | V2-Alpha Alias |
| :---          | :---           |
| user_id       | x_rec          |
| auth_token    | a_auth         |
| trace_id      | s_tid          |
| request_body  | p_load         |

## [STRICT OUTPUT PROTOCOL]
- File: `output/swe_l1_005.py`
- Content: The complete `build_request_v2` function definition ONLY.""",

        # --- Algorithm 领域 ---
        "kb/traversal_standards.md": """# SPEC-ALG-301: PRIORITY QUEUE
## Logic
- Tiers: Level (A > B > C).
- Intra-Tier: Score (Ascending).
- Rule: If `is_hidden == True`, force to bottom of the final list.
## [STRICT OUTPUT PROTOCOL]
- File: `output/alg_l1_001.csv`
- Header: `id` (single column).""",

        "kb/poly_folding.md": """# SPEC-ALG-302: HIERARCHY FLATTEN
## Logic
- Path: `parent/child`.
- Cycle: If a node repeats in the current path, append ` [RECURSIVE]` and stop.
## [STRICT OUTPUT PROTOCOL]
- File: `output/alg_l1_002.json`
- Format: List of path strings.""",

        "kb/balanced_cut.md": """# SPEC-ALG-303: ISOLATION CLIPPING
## Logic
- Barrier: Intervals with `force_split: True` are hard boundaries.
- No Merging: Do NOT combine overlapping regular tasks.
- Truncation: Regular tasks must be split or clipped to avoid Barrier ranges.
## [STRICT OUTPUT PROTOCOL]
- File: `output/alg_l1_003.csv`
- Columns: `task, start, end, is_barrier`
- Naming: 
    - Split tasks: Original + `_1`, `_2` (e.g., JobA_1).
    - Clipped tasks: Original name.
- Order: ASC by `start` time.""",

        "kb/bloom_config.md": """# SPEC-ALG-304: SCC RISK AUDIT
## Logic
- SCC: Identify Strongly Connected Components.
- Score: $RiskScore = (NodeCount) \\times (MaxWeightInSCC)$.
## [STRICT OUTPUT PROTOCOL]
- File: `output/alg_l1_004.json`
- Field: `cycle_nodes` must be **A-Z sorted** comma-separated string (e.g., "A,B").
- Order: Descending by `risk_score`.""",

        "kb/delta_varint_spec.md": """ # SPEC-ALG-305: FSM ROLLBACK
## Logic
- Command: On `ERROR_LIMIT`, pop the last **2** `MOVE` commands from history.
- Final State: Must transition to `STOP`.
## Field Definition: history_count
- This field represents the **final number of valid MOVE commands** remaining in the sequence after all ERROR_LIMIT rollbacks have been processed.
- Every `MOVE` adds 1.
- Every `ERROR_LIMIT` removes 2.
- The value cannot be negative (minimum is 0).
## [STRICT OUTPUT PROTOCOL]
- File: `output/alg_l1_005.json`
- Keys: `final_state`, `history_count`."""
    }
    
    for path, content in kbs.items():
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)

    print(f"Successfully generated {len(kbs)} KBs in /kb directory.")

if __name__ == "__main__":
    generate_all_kbs()