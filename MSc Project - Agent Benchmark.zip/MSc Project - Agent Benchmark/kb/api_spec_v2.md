# SPEC-SWE-205: CORPORATE API STANDARDS (V2)

## Section A: Service Migration
- Any stub labeled `V2-Alpha-Standard` must be refactored to use the new security aliases.
- Developers must fetch the correct mapping from the **Internal-Registry-Table** (see Section B).
- The legacy function (v1) in the source code is for reference only; do NOT reuse its keys.

## Section B: Internal-Registry-Table (Schema: AR-206)
| Legacy Field  | V2-Alpha Alias |
| :---          | :---           |
| user_id       | x_rec          |
| auth_token    | a_auth         |
| trace_id      | s_tid          |
| request_body  | p_load         |

## [STRICT OUTPUT PROTOCOL]
- File: `output/swe_l1_005.py`
- Content: The complete `build_request_v2` function definition ONLY.