# SPEC-ALG-303: ISOLATION CLIPPING
## Logic
- Barrier: Intervals with `force_split: True` are hard boundaries.
- No Merging: Do NOT combine overlapping regular tasks.
- Truncation: Regular tasks must be split or clipped to avoid Barrier ranges.
## [STRICT OUTPUT PROTOCOL]
- File: `output/alg_l1_003.csv`
- Columns: `task, start, end, is_barrier`
- Naming: 
    - Split tasks: Original + `_1`, `_2` (e.g., JobA_1).
    - Clipped tasks: Original name.
- Order: ASC by `start` time.