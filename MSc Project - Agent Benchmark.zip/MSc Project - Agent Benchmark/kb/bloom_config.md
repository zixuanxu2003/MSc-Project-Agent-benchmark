# SPEC-ALG-304: SCC RISK AUDIT
## Logic
- SCC: Identify Strongly Connected Components.
- Score: $RiskScore = (NodeCount) \times (MaxWeightInSCC)$.
## [STRICT OUTPUT PROTOCOL]
- File: `output/alg_l1_004.json`
- Field: `cycle_nodes` must be **A-Z sorted** comma-separated string (e.g., "A,B").
- Order: Descending by `risk_score`.