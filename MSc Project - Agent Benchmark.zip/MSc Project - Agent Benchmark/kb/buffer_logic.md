# SPEC-SWE-203: SHADOW TREE
## Logic
- Operation: For every `.py` file in `src/`, create a 0-byte file in `dist/shadow/`.
## [STRICT OUTPUT PROTOCOL]
- File: `output/swe_l1_003.txt`
- Naming: Original filename + `.py.meta`.
- Order: Alphabetical **A-Z** by filename.