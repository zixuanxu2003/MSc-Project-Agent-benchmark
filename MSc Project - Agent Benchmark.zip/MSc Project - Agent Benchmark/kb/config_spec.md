# SPEC-SWE-201: CONFIG MIGRATION
## Logic
- Parse `.ini` files. Ignore lines starting with `;` or `#`.
- Mapping: `$KEY=VAL` becomes `key: val`.
## [STRICT OUTPUT PROTOCOL]
- File: `output/swe_l1_001.json`
- Key: Mandatory **lowercase**.
- Injection: Root object must include `{"_standardized": true}`.