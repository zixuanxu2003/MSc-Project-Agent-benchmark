 # SPEC-ALG-305: FSM ROLLBACK
## Logic
- Command: On `ERROR_LIMIT`, pop the last **2** `MOVE` commands from history.
- Final State: Must transition to `STOP`.
## Field Definition: history_count
- This field represents the **final number of valid MOVE commands** remaining in the sequence after all ERROR_LIMIT rollbacks have been processed.
- Every `MOVE` adds 1.
- Every `ERROR_LIMIT` removes 2.
- The value cannot be negative (minimum is 0).
## [STRICT OUTPUT PROTOCOL]
- File: `output/alg_l1_005.json`
- Keys: `final_state`, `history_count`.