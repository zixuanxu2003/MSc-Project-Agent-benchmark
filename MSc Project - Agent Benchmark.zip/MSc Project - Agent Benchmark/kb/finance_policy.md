# SPEC-DS-102: FUND PENETRATION
## Logic
- Recursively sum all `sub_assets`.
- Weights: `Cash: 1.0`, `Type-K: 0.72`, `Other: 0.9`.
- Formula: $Exposure = \sum (Quantity \times Price \times Weight)$.
## [STRICT OUTPUT PROTOCOL]
- File: `output/ds_l1_002.json`
- Key: `total_net_exposure`
- Format: Round to **2 decimal places**.