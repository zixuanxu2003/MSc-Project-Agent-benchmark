# SPEC-SWE-202: SERVICE REGISTRY
## Logic
- Target: Only register classes with `@InternalRegister` decorator.
- Scope: Top-Level classes only. Ignore nested classes.
## [STRICT OUTPUT PROTOCOL]
- File: `output/swe_l1_002.json`
- Key: Decorator `alias` attribute, forced to **SCREAMING_SNAKE_CASE**.
- Value: Class Name (string).