# SPEC-DS-104: LOGISTICS AUDIT
## Logic
- Multiplier: 1.12x applies ONLY if (`Day == "Wednesday"` AND `Distance > 500`).
- Base: Apply to `base_cost`.
## [STRICT OUTPUT PROTOCOL]
- File: `output/ds_l1_004.csv`
- Headers: `trip_id`, `final_cost`
- Format: `final_cost` must be an **Integer** (round to nearest).