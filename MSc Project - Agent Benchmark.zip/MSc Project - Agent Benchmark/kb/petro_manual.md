# SPEC-DS-103: LOGARITHMIC DECAY
## Logic
- Model: $P_{adj} = P_{raw} \times (1 - 0.02 \times \ln(Depth))$
- Function: Use Natural Log (`math.log`).
## [STRICT OUTPUT PROTOCOL]
- File: `output/ds_l1_003.csv`
- Headers: `sample_id`, `p_adj`
- Format: `p_adj` must be **4 decimal places**.