# SPEC-ALG-302: HIERARCHY FLATTEN
## Logic
- Path: `parent/child`.
- Cycle: If a node repeats in the current path, append ` [RECURSIVE]` and stop.
## [STRICT OUTPUT PROTOCOL]
- File: `output/alg_l1_002.json`
- Format: List of path strings.