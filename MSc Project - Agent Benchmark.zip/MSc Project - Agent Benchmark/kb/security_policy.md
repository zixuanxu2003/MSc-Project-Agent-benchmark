# SPEC-SWE-204: VAULT INJECTION
## Logic
- Read the raw token from `data/vault.txt`.
- Check the `Security_Level` in `kb/security_keys.md`.
- **Rules**:
    - If `Security_Level` is 'HIGH', prefix the token with `ENC_`.
    - If 'LOW', use the raw token.
## [STRICT OUTPUT PROTOCOL]
- File: `output/swe_l1_004.env`
- Content: `VAULT_SECRET=[PROCESSED_TOKEN]`