# SPEC-DS-101: SENSOR CALIBRATION
## Logic
- Formula: $V_{out} = (V_{in} / 10.0) \times 0.85 + 0.15$
- Constraints: 
    - If $V_{in} > 10.0$, clamp to $10.0$.
    - If $V_{in} < 0.0$, clamp to $0.0$.
    - If $V_{in}$ is NaN, $V_{out}$ must be 0.1500.
## [STRICT OUTPUT PROTOCOL]
- File: `output/ds_l1_001.csv`
- Header: `v_norm`
- Format: Float, exactly **4 decimal places** (e.g., 0.5750).