# SPEC-ALG-301: PRIORITY QUEUE
## Logic
- Tiers: Level (A > B > C).
- Intra-Tier: Score (Ascending).
- Rule: If `is_hidden == True`, force to bottom of the final list.
## [STRICT OUTPUT PROTOCOL]
- File: `output/alg_l1_001.csv`
- Header: `id` (single column).