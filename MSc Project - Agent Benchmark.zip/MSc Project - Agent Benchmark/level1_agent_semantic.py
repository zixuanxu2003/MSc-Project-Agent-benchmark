from utils import predict_gpt, client
from sentence_transformers import SentenceTransformer
import os
import json
import numpy as np
import docker

embedding_model = SentenceTransformer('all-MiniLM-L6-v2')

kb_dir = "kb/"
documents = []
file_names = []
file_contents = []

docker_client = docker.from_env()

for file in os.listdir(kb_dir):
    if file.endswith(".md"):
        with open(os.path.join(kb_dir, file), 'r', encoding='utf-8') as f:
            content = f.read()
            documents.append(content)
            file_names.append(file)
            file_contents.append(content)

print(f"Loaded {len(documents)} documents from the knowledge base.")

print("Generating embeddings for the documents...")
doc_embeddings = embedding_model.encode(documents)
print("Embeddings generated.")

def semantic_search(query, top_k=3):
    query_embedding = embedding_model.encode([query])
    similarities = np.dot(doc_embeddings, query_embedding.T).flatten()
    top_indices = np.argsort(similarities)[-top_k:][::-1]

    results = []
    for idx in top_indices:
        results.append((file_names[idx], file_contents[idx], similarities[idx]))

    return "\n\n".join([f"File: {name}\nContent: {content}\nSimilarity: {similarity}" for name, content, similarity in results])

def run_code_in_sandbox(code):
    import tempfile
    import pwd, grp
    with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
        f.write(code)
        temp_path = f.name
        temp_filename = os.path.basename(temp_path)
    
    '''
    nobody_uid = pwd.getpwnam('nobody').pw_uid
    nobody_gid = grp.getgrnam('nobody').gr_gid
    os.chown(temp_path, nobody_uid, nobody_gid)
    os.chmod(temp_path, 0o644)
    '''

    try:
        work_dir = os.path.dirname(temp_path)
        project_dir = os.path.abspath(".")
        output_dir = os.path.abspath("output")
        os.makedirs(output_dir, exist_ok=True)
        dist_dir = os.path.abspath("dist")
        os.makedirs(dist_dir, exist_ok=True)

        #os.chown(work_dir, nobody_uid, nobody_gid)
        #os.chmod(work_dir, 0o755)

        container = docker_client.containers.run(
            image="my-sandbox:latest",
            command = f"python /workspace/code/{temp_filename}",
            volumes={work_dir: {'bind': '/workspace/code', 'mode': 'ro'},
                     project_dir: {'bind': '/workspace/project', 'mode': 'ro'},
                     output_dir: {'bind': '/workspace/project/output', 'mode': 'rw'},
                     dist_dir: {'bind': '/workspace/project/dist', 'mode': 'rw'}},
            working_dir="/workspace/project",
            mem_limit='512m',
            cap_drop=["ALL"],
            security_opt=["no-new-privileges:true"],
            user='root',
            detach=True,
            network_disabled=True
        )

        container.wait(timeout=30)
        logs = container.logs().decode()

        container.stop()
        container.remove()

        return logs, True
    except Exception as e:
        print(f"Error running code in sandbox: {e}")
        return str(e), False
    finally:
        os.unlink(temp_path)
        

def write_code_to_file(code, task_id):
    os.makedirs("generated_code", exist_ok=True)
    filename = f"generated_code/{task_id}.py"
    with open(filename, 'w') as f:
        f.write(code)
    print(f"Code written to {filename}")

    print("Running code in sandbox...")

    output_dir = "output/"
    before_files = set(os.listdir(output_dir) if os.path.exists(output_dir) else set())

    logs, success = run_code_in_sandbox(code)
    print(f"Sandbox logs:\n{logs}")

    after_files = set(os.listdir(output_dir) if os.path.exists(output_dir) else set())
    new_files = after_files - before_files
    if new_files:
        print(f"[Success] New output files generated: {new_files}")
        return True
    else:
        print("[Failure] No new output files generated.")
        return False    

def read_file(file_path):
    import pandas as pd
    import json
    
    if os.path.isdir(file_path):
        files = os.listdir(file_path)
        return f"Directory: {file_path}\nContains: {files}"
    if not os.path.exists(file_path) and not file_path.startswith("data/"):
        alt_path = os.path.join("data", file_path)
        if os.path.exists(alt_path):
            file_path = alt_path
        else:
            return f"Error: File not found: {file_path}"  
    
    if file_path.endswith('.csv'):
        df = pd.read_csv(file_path)
        return f"CSV file: {file_path}\nColumns: {list(df.columns)}\nFirst 5 rows:\n{df.head().to_string()}"
    
    elif file_path.endswith('.json'):
        with open(file_path, 'r') as f:
            data = json.load(f)
            return f"JSON file: {file_path}\nKeys: {list(data.keys())}\nSample:\n{json.dumps(data, indent=2)[:1000]}"

    elif file_path.endswith('.jsonl'):
        with open(file_path, 'r') as f:
            lines = [json.loads(line) for line in f if line.strip()]  
        return f"JSONL file: {file_path}\nNumber of records: {len(lines)}\nFirst record:\n{json.dumps(lines[0], indent=2)}"
    
    elif file_path.endswith('.db'):
        import sqlite3
        try:
            conn = sqlite3.connect(file_path)
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
            tables = cursor.fetchall()
            result = f"SQLite database: {file_path}\nTables: {[t[0] for t in tables]}\n"
            for table in tables:
                table_name = table[0]
                df = pd.read_sql_query(f"SELECT * FROM {table_name} LIMIT 5", conn)
                result += f"\nTable '{table_name}':\n{df.to_string()}\n"
            conn.close()
            return result
        except Exception as e:
            return f"Error reading SQLite DB: {e}"
    
    else:
        with open(file_path, 'r') as f:
            content = f.read()
            return f"Text file: {file_path}\nContent:\n{content[:2000]}"

tools = [{
    "type": "function",
    "function": {
        "name": "search_knowledge_base",
        "description": "Search the knowledge base for specific documents",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The search query"
                },
            },
            "required": ["query"],
            "additionalProperties": False
        },
        "strict": True
    }
},
{
    "type": "function",
    "function": {
        "name": "write_code",
        "description": "Write Python code to a file",
        "parameters": {
            "type": "object",
            "properties": {
                "code": {
                    "type": "string",
                    "description": "The Python code to write"
                },
                "filename": {
                    "type": "string",
                    "description": "The name of the file to write the code to"
                }
            },
            "required": ["code", "filename"],
            "additionalProperties": False
        },
        "strict": True
    }
},
{
    "type": "function",
    "function": {
        "name": "read_file",
        "description": "Read a file from the filesystem. Suports .csv, .json, .jsonl, .txt, .env, .py, .ini, .db.",
        "parameters": {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Path to the file to read"
                }
            },
            "required": ["file_path"],
            "additionalProperties": False
        },
    }
}]

''' #############################TEST############################## 
task_description = """Task: Normalize industrial vibration telemetry in 'data/vibration.csv'. 
Ensure the output meets the specific calibration precision and range required for turbine monitoring.

Steps:
1. Use search_knowledge_base to find the correct specification file
2. Extract the logic and output protocol from the specification
3. Write Python code to process the input file and produce the output strictly following the specification.
"""

messages = [
    {"role": "system", "content": "You are an AI assistant that writes Python code to solve the given task. First use search_knowledge_base to find specs. Then use read_file to inspect the input file. Finally, use write_code to save code."},
    {"role": "user", "content": task_description}
]

print("Round 1: Agent calling tool...")
msg1 = predict_gpt(client, messages, tools=tools)
messages.append(msg1)

if msg1.tool_calls:
    for tc in msg1.tool_calls:
        if tc.function.name == "search_knowledge_base":
            args = json.loads(tc.function.arguments)
            query = args['query']
            print(f"Agent called search_knowledge_base with query: {query}")
            search_results = semantic_search(query)
            print(f"Search results:\n{search_results}")
            messages.append({"role": "tool", "tool_call_id": tc.id, "content": search_results})

print("Round 2: Agent reading input file...")
msg2 = predict_gpt(client, messages, tools=tools)
messages.append(msg2)

if msg2.tool_calls:
    for tc in msg2.tool_calls:
        if tc.function.name == "read_file":
            args = json.loads(tc.function.arguments)
            file_path = args['file_path']
            print(f"Agent called read_file with file_path: {file_path}")
            file_content = read_file(file_path)
            print(f"File content:\n{file_content}")
            messages.append({"role": "tool", "tool_call_id": tc.id, "content": file_content})

print("Round 3: Agent generating code...")
msg3 = predict_gpt(client, messages, tools=tools)

messages.append(msg3)

if msg3.tool_calls:
    for tc in msg3.tool_calls:
        if tc.function.name == "write_code":
            args = json.loads(tc.function.arguments)
            code = args['code']
            filename = args['filename']
            print(f"Agent called write_code with filename: {filename}")
            write_code_to_file(code, filename)

elif msg3.content:
    print("Agent response without tool call:")
    print(msg3.content)
else:
    print("Agent did not call any tools or return content.")
'''

# SEQUENTIAL VERSION
'''
def run_single_task(task):
    task_id = task['task_id']
    initial_prompt = task['initial_prompt']
    input_file = task['input_file']
    
    print(f"\n{'='*60}")
    print(f"Running {task_id}")
    print(f"Input: {input_file}")
    print(f"{'='*60}")

    messages = [
        {"role": "system", "content": "You are an AI assistant that writes Python code to solve the given task. First use search_knowledge_base to find specs. Then use read_file to inspect the input file. Finally, use write_code to save code."},
        {"role": "user", "content": initial_prompt}
    ]

    print("Round 1: Agent must search knowledge base...")
    msg1 = predict_gpt(client, messages, tools=tools, tool_choice="required")
    messages.append(msg1)

    if not msg1.tool_calls:
        print("Agent did not search. Failing task.")
        return {
            "task_id": task_id,
            "success": False
        }
    searched = False
    for tc in msg1.tool_calls:
        if tc.function.name == "search_knowledge_base":
            searched = True
            args = json.loads(tc.function.arguments)
            query = args['query']
            print(f"Agent called search_knowledge_base with query: {query}")
            search_results = semantic_search(query)
            print(f"Search results:\n{search_results}")
            messages.append({"role": "tool", "tool_call_id": tc.id, "content": search_results})
            break
    
    if not searched:
        print("Agent called wrong tool. Failing task.")
        return {
            "task_id": task_id,
            "success": False
        }
    
    print("Round 2: Agent must read input file...")
    msg2 = predict_gpt(client, messages, tools=tools)
    messages.append(msg2)

    if not msg2.tool_calls:
        print("Agent did not read file. Failing task.")
        return {
            "task_id": task_id,
            "success": False
        }
    
    read = False
    for tc in msg2.tool_calls:
        if tc.function.name == "read_file":
            read = True
            args = json.loads(tc.function.arguments)
            file_path = args['file_path']
            print(f"Agent called read_file with file_path: {file_path}")
            file_content = read_file(file_path)
            print(f"File content:\n{file_content}")
            messages.append({"role": "tool", "tool_call_id": tc.id, "content": file_content})
            break
    
    if not read:
        print("Agent called wrong tool. Failing task.")
        return {
            "task_id": task_id,
            "success": False
        }
    
    print("Round 3: Agent generating code...")
    msg3 = predict_gpt(client, messages, tools=tools)
    messages.append(msg3)
    
    if msg3.tool_calls:
        for tc in msg3.tool_calls:
            if tc.function.name == "write_code":
                args = json.loads(tc.function.arguments)
                code = args['code']
                filename = args.get('filename', f"generated_code/{task_id}.py")
                print(f"Agent called write_code with filename: {filename}")
                success = write_code_to_file(code, task_id)

                return {
                    "task_id": task_id,
                    "success": success
                }

    else:
        print("Agent did not call write_code tool.")
        return {
            "task_id": task_id,
            "success": False
        }
'''

# NON-SEQUENTIAL VERSION
def run_single_task(task):
    task_id = task['task_id']
    initial_prompt = task['initial_prompt']
    input_file = task['input_file']
    
    print(f"\n{'='*60}")
    print(f"Running {task_id}")
    print(f"Input: {input_file}")
    print(f"{'='*60}")

    messages = [
        {"role": "system", "content": "You are an AI assistant that writes Python code to solve the given task. First use search_knowledge_base to find specs. Then use read_file to inspect the input file. Finally, use write_code to save code."},
        {"role": "user", "content": initial_prompt}
    ]

    has_searched = False
    has_read = False
    has_written = False

    max_rounds = 5
    for round in range(max_rounds):
        print(f"Round {round+1}: Agent thinking...")
        msg = predict_gpt(client, messages, tools=tools, tool_choice="auto")
        messages.append(msg)

        if not msg.tool_calls:
            print("Agent finished without tool calls.")
            break
        
        for tc in msg.tool_calls:
            if tc.function.name == "search_knowledge_base":
                args = json.loads(tc.function.arguments)
                query = args['query']
                print(f"Agent called search_knowledge_base with query: {query}")
                search_results = semantic_search(query)
                print(f"Search results:\n{search_results}")
                messages.append({"role": "tool", "tool_call_id": tc.id, "content": search_results})
                has_searched = True

            elif tc.function.name == "read_file":
                args = json.loads(tc.function.arguments)
                file_path = args['file_path']
                print(f"Agent called read_file with file_path: {file_path}")
                file_content = read_file(file_path)
                print(f"File content:\n{file_content}")
                messages.append({"role": "tool", "tool_call_id": tc.id, "content": file_content})
                has_read = True

            elif tc.function.name == "write_code" :
                args = json.loads(tc.function.arguments)
                code = args['code']
                filename = args.get('filename', f"generated_code/{task_id}.py")
                print(f"Agent called write_code with filename: {filename}")
                success = write_code_to_file(code, task_id)
                has_written = True

                return {
                    "task_id": task_id,
                    "success": success
                }
    
    if not has_searched:
        print("[Wrong]Agent never searched")
    if not has_read:
        print("[Wrong]Agent never read input file")
    if not has_written:
        print("[Wrong]Agent never wrote code")
    
    return {"task_id": task_id, "success": False, "has_searched": has_searched, "has_read": has_read, "has_written": has_written}


if __name__ == "__main__":
    import json
    
    with open('level1.jsonl') as f:
        tasks = [json.loads(line) for line in f if line.strip()]
    
    os.makedirs("results", exist_ok=True)
    os.makedirs("output", exist_ok=True)

    results = []
    for task in tasks:
        try:
            result = run_single_task(task)
            results.append(result)
            with open(f"results/{task['task_id']}.json", 'w') as f:
                json.dump(result, f, indent=2)
        except Exception as e:
            print(f"Error: {e}")
            results.append({
                "task_id": task['task_id'],
                "success": False,
                "error": str(e)
            })
    
    with open("results/summary.json", 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"\n{'='*60}")
    print(f"Success: {sum(1 for r in results if r['success'])}/{len(results)}")
    for r in results:
        print(f"  {'[Success]' if r['success'] else '[Failed]'} {r['task_id']}")
    