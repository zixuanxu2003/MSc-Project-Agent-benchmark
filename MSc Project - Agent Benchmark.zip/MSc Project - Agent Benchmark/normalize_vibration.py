import pandas as pd

# Load the raw vibration data
vibration_df = pd.read_csv('data/vibration.csv')

# Normalization logic from the specification
# Clamp the input between 0.0 and 10.0
vibration_df['v_clamped'] = vibration_df['v_raw'].clip(lower=0.0, upper=10.0)

# Apply the formula: (v_in / 10.0) * 0.85 + 0.15
vibration_df['v_norm'] = (vibration_df['v_clamped'] / 10.0) * 0.85 + 0.15

# If the input is NaN, output should be 0.1500
vibration_df.loc[vibration_df['v_raw'].isna(), 'v_norm'] = 0.1500

# Format output to 4 decimal places
vibration_df['v_norm'] = vibration_df['v_norm'].map(lambda x: f"{x:.4f}")

# Prepare output file with strict header
output_df = vibration_df[['v_norm']]
output_df.to_csv('output/ds_l1_001.csv', index=False)