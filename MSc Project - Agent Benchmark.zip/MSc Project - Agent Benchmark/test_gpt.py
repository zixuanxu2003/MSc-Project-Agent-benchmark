from utils import predict_gpt, client

test = predict_gpt(client, [{"role": "user", "content": "Say hello"}])

print(test)