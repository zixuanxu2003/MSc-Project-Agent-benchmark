import openai
import os
from dotenv import load_dotenv
from ctoken import ctoken

load_dotenv()

openai.api_key = os.getenv('OPENAI_API_KEY')

client = openai.OpenAI()

def predict_gpt(openai_m, messages, tools=None, tool_choice=None):
    response = client.chat.completions.create(
        model = "gpt-4.1-mini",
        messages = messages,
        tools = tools,
        tool_choice = tool_choice
    )

    cost = ctoken(response)

    print(f"[Token] prompt: {cost['prompt_tokens']}, completion: {cost['completion_tokens']}, total: {cost['total_tokens']}, cost: ${cost['total_cost']:.6f}")

    return response.choices[0].message